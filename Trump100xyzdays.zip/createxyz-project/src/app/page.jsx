"use client";
import React from "react";

import { useHandleStreamResponse } from "../utilities/runtime-helpers";

function MainComponent() {
  const [day, setDay] = useState("1");
  const [prediction, setPrediction] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const handleStreamResponse = useHandleStreamResponse({
    onChunk: setStreamingContent,
    onFinish: (content) => {
      setPrediction(content);
      setStreamingContent("");
      setIsGenerating(false);
    },
  });
  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Trump's First 100 Days - Day ${day} Prediction`,
          text: prediction,
          url: window.location.href,
        });
      } catch (error) {
        console.error("Error sharing:", error);
      }
    } else {
      try {
        await navigator.clipboard.writeText(prediction);
        alert("Prediction copied to clipboard!");
      } catch (error) {
        console.error("Error copying to clipboard:", error);
      }
    }
  };
  const generatePrediction = async () => {
    setIsGenerating(true);
    const messages = [
      {
        role: "system",
        content:
          "You are an expert political analyst specializing in predicting and analyzing political events. Provide detailed, factual analysis based on historical patterns and current context.",
      },
      {
        role: "user",
        content: `Predict and analyze what Donald Trump might do on Day ${day} of his first 100 days back in office. Consider:
      1. Historical patterns from his previous presidency
      2. Current political climate
      3. His stated priorities and promises
      4. Potential executive orders and policy changes
      
      Format the response with:
      - Date and Day Number
      - Key Predictions
      - Detailed Analysis
      - Potential Impact`,
      },
    ];

    const response = await fetch("/integrations/anthropic-claude-sonnet-3-5/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages, stream: true }),
    });

    handleStreamResponse(response);
  };
  const searchTopResults = async () => {
    setIsSearching(true);
    try {
      const response = await fetch(
        `/integrations/google-search/search?q=${encodeURIComponent(title)}`
      );
      const data = await response.json();
      setSearchResults(data.items.slice(0, 10));
    } catch (error) {
      console.error("Search error:", error);
    }
    setIsSearching(false);
  };

  return (
    <>
      <head>
        <title>
          Trump's First 100 Days Timeline | Political Analysis & Predictions
        </title>
        <meta
          name="description"
          content="Expert analysis and daily predictions of Donald Trump's potential actions during his first 100 days back in office. Historical patterns, policy changes, and impact analysis."
        />
        <meta
          name="keywords"
          content="Trump first 100 days, political predictions, Trump presidency, political analysis, executive orders"
        />
        <meta
          property="og:title"
          content="Trump's First 100 Days Timeline | Political Analysis & Predictions"
        />
        <meta
          property="og:description"
          content="Expert analysis and daily predictions of Donald Trump's potential actions during his first 100 days back in office."
        />
        <meta
          property="og:image"
          content="https://ucarecdn.com/5b48c1d2-64e7-4b48-9709-63de66ac3d60/-/format/auto/"
        />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://trump-100-days.netlify.app" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Trump's First 100 Days Timeline" />
        <meta
          name="twitter:description"
          content="Expert political analysis and predictions for Trump's first 100 days."
        />
        <meta
          name="twitter:image"
          content="https://ucarecdn.com/5b48c1d2-64e7-4b48-9709-63de66ac3d60/-/format/auto/"
        />
        <link rel="canonical" href="https://trump-100-days.netlify.app" />
        <meta name="robots" content="index, follow" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </head>
      <div className="min-h-screen bg-white p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col space-y-8">
            <div className="text-center">
              <div className="mb-6">
                <img
                  src="https://ucarecdn.com/5b48c1d2-64e7-4b48-9709-63de66ac3d60/-/format/auto/"
                  alt="Empire State Building towering over New York City skyline with One World Trade Center visible in the background"
                  className="w-full h-[400px] object-cover rounded-lg shadow-md"
                  loading="eager"
                  width="1200"
                  height="400"
                />
                <p className="text-xs text-gray-500 mt-1 font-roboto">
                  New York City Skyline
                </p>
                <div className="flex flex-wrap justify-center gap-4 mt-4">
                  <a
                    href="https://039d4yzhizjs1n7gmm1rx72xeh.hop.clickbank.net/?&traffic_source=google&traffic_type=blog&campaign=spring&creative=video"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg font-roboto text-sm text-gray-700 transition-colors"
                  >
                    <i className="fas fa-link mr-2"></i>
                    Featured Link 1
                  </a>
                  <a
                    href="https://de8bf2xam06u2t28n114jdq79m.hop.clickbank.net/?&traffic_source=google&traffic_type=blog&campaign=spring&creative=video"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg font-roboto text-sm text-gray-700 transition-colors"
                  >
                    <i className="fas fa-link mr-2"></i>
                    Featured Link 2
                  </a>
                  <a
                    href="https://44d2b6unmtqmrb3lyj0gad9weu.hop.clickbank.net/?&traffic_source=google&traffic_type=click&campaign=spring&creative=video"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg font-roboto text-sm text-gray-700 transition-colors"
                  >
                    <i className="fas fa-link mr-2"></i>
                    Featured Link 3
                  </a>
                </div>
              </div>
              <h1 className="text-4xl font-roboto font-bold text-gray-900 mb-4">
                Trump's First 100 Days Timeline
              </h1>
              <p className="text-gray-600 font-roboto mb-8 max-w-2xl mx-auto">
                Expert daily predictions and comprehensive analysis of Donald
                Trump's potential actions, based on historical patterns, current
                political climate, and stated priorities.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <h2 className="text-2xl font-roboto text-gray-800 mb-6">
                  Day-by-Day Prediction Generator
                </h2>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <input
                      type="number"
                      min="1"
                      max="100"
                      placeholder="Enter day (1-100)"
                      value={day}
                      onChange={(e) => setDay(e.target.value)}
                      className="w-32 p-3 border border-gray-300 rounded-lg font-roboto"
                      name="day"
                    />
                    <button
                      onClick={generatePrediction}
                      disabled={isGenerating || !day || day < 1 || day > 100}
                      className="px-6 py-3 bg-gray-800 text-white rounded-lg font-roboto hover:bg-gray-700 disabled:bg-gray-400"
                    >
                      {isGenerating ? "Generating..." : "Generate Prediction"}
                    </button>
                  </div>
                </div>

                {searchResults.length > 0 && (
                  <div className="mt-8">
                    <h3 className="text-lg font-roboto text-gray-800 mb-4">
                      Top 10 Search Results
                    </h3>
                    <div className="space-y-3 max-h-[400px] overflow-y-auto">
                      {searchResults.map((result, index) => (
                        <div
                          key={index}
                          className="p-3 border border-gray-200 rounded-lg"
                        >
                          <a
                            href={result.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 font-roboto"
                          >
                            {result.title}
                          </a>
                          <p className="text-sm text-gray-600 font-roboto mt-1">
                            {result.snippet}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              <div className="bg-gray-50 p-6 rounded-lg">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-roboto text-gray-800">
                    Day {day} Prediction
                  </h2>
                  {prediction && !isGenerating && (
                    <button
                      onClick={handleShare}
                      className="px-4 py-2 bg-gray-800 text-white rounded-lg font-roboto hover:bg-gray-700 flex items-center gap-2"
                    >
                      <i className="fas fa-share-alt"></i>
                      Share
                    </button>
                  )}
                </div>
                <div className="prose max-w-none font-roboto">
                  {isGenerating ? (
                    <div className="animate-pulse">
                      {streamingContent || "Generating prediction..."}
                    </div>
                  ) : (
                    <div className="whitespace-pre-wrap">{prediction}</div>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-12 bg-gray-50 p-8 rounded-lg">
              <h2 className="text-2xl font-roboto font-bold text-gray-900 mb-6 text-center">
                Sponsored Links
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <a
                  href="https://803347wjwocz0w3ahsk54jpn8z.hop.clickbank.net/?&traffic_source=blog&traffic_type=google&campaign=spring&creative=video"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="text-center">
                    <i className="fas fa-gift text-3xl text-blue-500 mb-3"></i>
                    <p className="font-roboto text-gray-800">Special Offer 1</p>
                  </div>
                </a>
                <a
                  href="https://prodentim.com/text.php?&shield=2ee289q9nzkmar8j1ktbwllka3&traffic_source=google&traffic_type=blog&campaign=spring&creative=video"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="text-center">
                    <i className="fas fa-star text-3xl text-yellow-500 mb-3"></i>
                    <p className="font-roboto text-gray-800">Special Offer 2</p>
                  </div>
                </a>
                <a
                  href="https://5e4df3meqw9v4m6figzjva6r0x.hop.clickbank.net/?&traffic_source=google&traffic_type=blog&campaign=spring&creative=video"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="text-center">
                    <i className="fas fa-heart text-3xl text-red-500 mb-3"></i>
                    <p className="font-roboto text-gray-800">Special Offer 3</p>
                  </div>
                </a>
                <a
                  href="https://872c1wpaor9o4u22wprgltfwdo.hop.clickbank.net/?&traffic_source=google&traffic_type=blog&campaign=spring&creative=video"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block p-4 bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow"
                >
                  <div className="text-center">
                    <i className="fas fa-gem text-3xl text-purple-500 mb-3"></i>
                    <p className="font-roboto text-gray-800">Special Offer 4</p>
                  </div>
                </a>
              </div>
            </div>

            <div className="mt-8 bg-gray-50 p-8 rounded-lg">
              <h2 className="text-2xl font-roboto font-bold text-gray-900 mb-6 text-center">
                Support Our Work
              </h2>
              <div className="flex flex-col md:flex-row justify-center items-center gap-8">
                <div className="text-center">
                  <form
                    action="https://www.paypal.com/donate"
                    method="post"
                    target="_blank"
                  >
                    <input
                      type="hidden"
                      name="business"
                      value="robertaworkjr@gmail.com"
                    />
                    <input type="hidden" name="amount" value="1.00" />
                    <input type="hidden" name="currency_code" value="USD" />
                    <button
                      type="submit"
                      className="px-6 py-3 bg-[#0070BA] text-white rounded-lg font-roboto hover:bg-[#003087] transition-colors flex items-center gap-2"
                    >
                      <i className="fab fa-paypal"></i>
                      Donate $1 with PayPal
                    </button>
                  </form>
                </div>
                <div className="text-center">
                  <a
                    href="https://buy.stripe.com/7sI28V7Rb0E96UU8wx"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-6 py-3 bg-[#635BFF] text-white rounded-lg font-roboto hover:bg-[#4B45C6] transition-colors flex items-center gap-2"
                  >
                    <i className="fab fa-stripe"></i>
                    Pay with Stripe
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <script type="application/ld+json">
          {`
            {
              "@context": "https://schema.org",
              "@type": "Article",
              "headline": "Trump's First 100 Days Timeline",
              "description": "Expert analysis and daily predictions of Donald Trump's potential actions during his first 100 days back in office.",
              "image": "https://ucarecdn.com/5b48c1d2-64e7-4b48-9709-63de66ac3d60/-/format/auto/",
              "author": {
                "@type": "Organization",
                "name": "Political Analysis Team"
              },
              "publisher": {
                "@type": "Organization",
                "name": "Political Analysis Team",
                "logo": {
                  "@type": "ImageObject",
                  "url": "https://ucarecdn.com/5b48c1d2-64e7-4b48-9709-63de66ac3d60/-/format/auto/"
                }
              },
              "datePublished": "2025-01-01",
              "dateModified": "2025-01-01"
            }
          `}
        </script>
      </div>
    </>
  );
}

export default MainComponent;